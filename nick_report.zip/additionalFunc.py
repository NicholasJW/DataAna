
def p2f(x):
    return float(x.strip('%'))/100